"""
World-Class Spanish Political NER System

Enhanced Named Entity Recognition specialized for Argentine political discourse
using state-of-the-art Spanish language models.
"""

import spacy
import re
import logging
from typing import Dict, List, Tuple, Set
from dataclasses import dataclass
from collections import defaultdict

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("Transformers not available. Install with: pip install transformers")

@dataclass
class PoliticalEntity:
    """Enhanced political entity with comprehensive metadata."""
    text: str
    label: str
    start: int
    end: int
    confidence: float
    entity_type: str
    subtype: str = None
    temporal_scope: Tuple[int, int] = None  # (start_year, end_year)
    geographic_scope: str = None
    political_family: str = None

class WorldClassPoliticalNER:
    """
    World-class NER system for Argentine political analysis.
    
    Uses multiple models and rule-based enhancement for comprehensive
    entity extraction meeting publication standards.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Initialize models
        self.spanish_ner = None
        self.political_ner = None
        self.spacy_model = None
        
        # Entity type mapping for political domain
        self.entity_mapping = {
            'PERSON': 'political_actor',
            'PER': 'political_actor', 
            'ORG': 'political_organization',
            'LOC': 'geographic_entity',
            'MISC': 'political_concept',
            'GPE': 'geographic_political_entity',
            'EVENT': 'political_event',
            'LAW': 'legal_framework',
            'DATE': 'temporal_reference'
        }
        
        # Political subtypes for fine-grained classification
        self.political_subtypes = {
            'political_actor': [
                'president', 'vice_president', 'minister', 'governor', 
                'mayor', 'senator', 'deputy', 'judge', 'military_leader',
                'union_leader', 'party_leader', 'activist'
            ],
            'political_organization': [
                'political_party', 'movement', 'coalition', 'faction',
                'union', 'ngo', 'think_tank', 'media_outlet'
            ],
            'political_concept': [
                'ideology', 'doctrine', 'policy', 'reform', 'crisis',
                'democracy', 'federalism', 'peronism', 'radicalismo'
            ],
            'legal_framework': [
                'constitution', 'law', 'decree', 'resolution', 'treaty',
                'amendment', 'regulation', 'ordinance'
            ]
        }
        
        # Known political entities for validation
        self.known_entities = self._load_political_gazetteer()
        
        self._initialize_models()
    
    def _initialize_models(self):
        """Initialize all NER models."""
        try:
            if TRANSFORMERS_AVAILABLE:
                # Spanish BERT for general NER
                self.spanish_ner = pipeline(
                    "ner", 
                    model="dccuchile/bert-base-spanish-wwm-cased-finetuned-ner",
                    aggregation_strategy="simple"
                )
                
                # Alternative model for better coverage
                self.political_ner = pipeline(
                    "ner",
                    model="mrm8488/RuPERTa-base-finetuned-ner",
                    aggregation_strategy="simple"
                )
                
                self.logger.info("Transformer models loaded successfully")
            
            # Load spaCy model for additional processing
            try:
                self.spacy_model = spacy.load("es_core_news_sm")
                self.logger.info("spaCy Spanish model loaded")
            except OSError:
                self.logger.warning("spaCy Spanish model not found. Install with: python -m spacy download es_core_news_sm")
                
        except Exception as e:
            self.logger.error(f"Error initializing models: {e}")
            
    def _load_political_gazetteer(self) -> Dict[str, Dict]:
        """Load comprehensive gazetteer of Argentine political entities."""
        
        # Historical presidents (1810-2025)
        presidents = {
            'Bernardino Rivadavia': {'type': 'president', 'period': (1826, 1827), 'family': 'Unitario'},
            'Juan Manuel de Rosas': {'type': 'governor', 'period': (1829, 1852), 'family': 'Federal'},
            'Justo José de Urquiza': {'type': 'president', 'period': (1854, 1860), 'family': 'Federal'},
            'Bartolomé Mitre': {'type': 'president', 'period': (1862, 1868), 'family': 'Liberal'},
            'Domingo Faustino Sarmiento': {'type': 'president', 'period': (1868, 1874), 'family': 'Liberal'},
            'Nicolás Avellaneda': {'type': 'president', 'period': (1874, 1880), 'family': 'Liberal'},
            'Julio Argentino Roca': {'type': 'president', 'period': (1880, 1886), 'family': 'Conservador'},
            'Miguel Juárez Celman': {'type': 'president', 'period': (1886, 1890), 'family': 'Conservador'},
            'Carlos Pellegrini': {'type': 'president', 'period': (1890, 1892), 'family': 'Conservador'},
            'Luis Sáenz Peña': {'type': 'president', 'period': (1892, 1895), 'family': 'Conservador'},
            'José Evaristo Uriburu': {'type': 'president', 'period': (1895, 1898), 'family': 'Conservador'},
            'Roque Sáenz Peña': {'type': 'president', 'period': (1910, 1914), 'family': 'Conservador'},
            'Victorino de la Plaza': {'type': 'president', 'period': (1914, 1916), 'family': 'Conservador'},
            'Hipólito Yrigoyen': {'type': 'president', 'period': (1916, 1922), 'family': 'Radical'},
            'Marcelo T. de Alvear': {'type': 'president', 'period': (1922, 1928), 'family': 'Radical'},
            'Juan Domingo Perón': {'type': 'president', 'period': (1946, 1955), 'family': 'Peronista'},
            'Eva Duarte de Perón': {'type': 'first_lady', 'period': (1946, 1952), 'family': 'Peronista'},
            'Arturo Frondizi': {'type': 'president', 'period': (1958, 1962), 'family': 'Radical'},
            'Arturo Illia': {'type': 'president', 'period': (1963, 1966), 'family': 'Radical'},
            'Héctor Cámpora': {'type': 'president', 'period': (1973, 1973), 'family': 'Peronista'},
            'Raúl Alfonsín': {'type': 'president', 'period': (1983, 1989), 'family': 'Radical'},
            'Carlos Menem': {'type': 'president', 'period': (1989, 1999), 'family': 'Peronista'},
            'Fernando de la Rúa': {'type': 'president', 'period': (1999, 2001), 'family': 'Radical'},
            'Eduardo Duhalde': {'type': 'president', 'period': (2002, 2003), 'family': 'Peronista'},
            'Néstor Kirchner': {'type': 'president', 'period': (2003, 2007), 'family': 'Kirchnerista'},
            'Cristina Fernández de Kirchner': {'type': 'president', 'period': (2007, 2015), 'family': 'Kirchnerista'},
            'Mauricio Macri': {'type': 'president', 'period': (2015, 2019), 'family': 'PRO'},
            'Alberto Fernández': {'type': 'president', 'period': (2019, 2023), 'family': 'Peronista'},
            'Javier Milei': {'type': 'president', 'period': (2023, 2025), 'family': 'Libertario'}
        }
        
        # Political parties and movements
        parties = {
            'Partido Justicialista': {'type': 'party', 'family': 'Peronista', 'founded': 1947},
            'Unión Cívica Radical': {'type': 'party', 'family': 'Radical', 'founded': 1891},
            'Propuesta Republicana': {'type': 'party', 'family': 'PRO', 'founded': 2005},
            'La Cámpora': {'type': 'movement', 'family': 'Kirchnerista', 'founded': 2006},
            'Frente de Todos': {'type': 'coalition', 'family': 'Peronista', 'founded': 2019},
            'Juntos por el Cambio': {'type': 'coalition', 'family': 'Oposición', 'founded': 2015},
            'La Libertad Avanza': {'type': 'party', 'family': 'Libertario', 'founded': 2021},
            'Frente Cívico y Social': {'type': 'coalition', 'family': 'Centro', 'founded': 2023}
        }
        
        # Key political concepts
        concepts = {
            'peronismo': {'type': 'ideology', 'period': (1946, 2025)},
            'radicalismo': {'type': 'ideology', 'period': (1891, 2025)},
            'kirchnerismo': {'type': 'movement', 'period': (2003, 2025)},
            'macrismo': {'type': 'movement', 'period': (2007, 2025)},
            'federalismo': {'type': 'doctrine', 'period': (1810, 2025)},
            'unitarismo': {'type': 'doctrine', 'period': (1810, 1860)},
            'neoliberalismo': {'type': 'doctrine', 'period': (1990, 2025)},
            'populismo': {'type': 'doctrine', 'period': (1946, 2025)},
            'grieta': {'type': 'concept', 'period': (2008, 2025)},
            'golpe de estado': {'type': 'event_type', 'period': (1810, 2025)}
        }
        
        # Legal frameworks
        laws = {
            'Constitución Nacional': {'type': 'constitution', 'year': 1853},
            'Ley Sáenz Peña': {'type': 'electoral_law', 'year': 1912},
            'Ley de Matrimonio Igualitario': {'type': 'civil_rights_law', 'year': 2010},
            'Ley de Medios': {'type': 'media_law', 'year': 2009},
            'Reforma Constitucional': {'type': 'constitutional_reform', 'year': 1994}
        }
        
        # Combine all gazetteers
        gazetteer = {}
        gazetteer.update(presidents)
        gazetteer.update(parties)
        gazetteer.update(concepts)
        gazetteer.update(laws)
        
        return gazetteer
    
    def extract_entities(self, text: str, doc_year: int = None) -> List[PoliticalEntity]:
        """
        Extract all political entities from text using multiple approaches.
        
        Args:
            text (str): Input text to analyze
            doc_year (int): Year of document for temporal validation
            
        Returns:
            List[PoliticalEntity]: Comprehensive list of extracted entities
        """
        entities = []
        
        # 1. Transformer-based extraction
        if self.spanish_ner:
            transformer_entities = self._extract_with_transformers(text)
            entities.extend(transformer_entities)
        
        # 2. spaCy-based extraction
        if self.spacy_model:
            spacy_entities = self._extract_with_spacy(text)
            entities.extend(spacy_entities)
        
        # 3. Gazetteer-based extraction
        gazetteer_entities = self._extract_with_gazetteer(text, doc_year)
        entities.extend(gazetteer_entities)
        
        # 4. Pattern-based extraction
        pattern_entities = self._extract_with_patterns(text)
        entities.extend(pattern_entities)
        
        # 5. Deduplicate and enhance
        final_entities = self._deduplicate_and_enhance(entities, text, doc_year)
        
        self.logger.info(f"Extracted {len(final_entities)} entities from text")
        return final_entities
    
    def _extract_with_transformers(self, text: str) -> List[PoliticalEntity]:
        """Extract entities using transformer models."""
        entities = []
        
        for model_name, model in [('spanish_ner', self.spanish_ner), ('political_ner', self.political_ner)]:
            if model is None:
                continue
                
            try:
                results = model(text)
                for result in results:
                    entity = PoliticalEntity(
                        text=result['word'],
                        label=result['entity_group'],
                        start=result['start'],
                        end=result['end'],
                        confidence=result['score'],
                        entity_type=self.entity_mapping.get(result['entity_group'], 'unknown')
                    )
                    entities.append(entity)
            except Exception as e:
                self.logger.error(f"Error with {model_name}: {e}")
        
        return entities
    
    def _extract_with_spacy(self, text: str) -> List[PoliticalEntity]:
        """Extract entities using spaCy."""
        entities = []
        
        if self.spacy_model is None:
            return entities
        
        try:
            doc = self.spacy_model(text)
            for ent in doc.ents:
                entity = PoliticalEntity(
                    text=ent.text,
                    label=ent.label_,
                    start=ent.start_char,
                    end=ent.end_char,
                    confidence=0.8,  # spaCy doesn't provide confidence scores
                    entity_type=self.entity_mapping.get(ent.label_, 'unknown')
                )
                entities.append(entity)
        except Exception as e:
            self.logger.error(f"Error with spaCy: {e}")
        
        return entities
    
    def _extract_with_gazetteer(self, text: str, doc_year: int = None) -> List[PoliticalEntity]:
        """Extract entities using political gazetteer."""
        entities = []
        
        for entity_name, entity_info in self.known_entities.items():
            # Case-insensitive search
            pattern = re.compile(re.escape(entity_name), re.IGNORECASE)
            
            for match in pattern.finditer(text):
                # Temporal validation
                if doc_year and 'period' in entity_info:
                    start_year, end_year = entity_info['period']
                    if not (start_year <= doc_year <= end_year):
                        continue
                
                entity = PoliticalEntity(
                    text=match.group(),
                    label=entity_info.get('type', 'UNKNOWN'),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.95,  # High confidence for gazetteer matches
                    entity_type=entity_info.get('type', 'unknown'),
                    temporal_scope=entity_info.get('period'),
                    political_family=entity_info.get('family')
                )
                entities.append(entity)
        
        return entities
    
    def _extract_with_patterns(self, text: str) -> List[PoliticalEntity]:
        """Extract entities using regex patterns."""
        entities = []
        
        # Political title patterns
        title_patterns = [
            (r'\b(?:Presidente|Vicepresidente|Ministro|Gobernador|Intendente|Senador|Diputado)\s+([A-Z][a-záéíóúñü\s]+)', 'political_actor'),
            (r'\b(?:Ley|Decreto|Resolución)\s+(?:N°?\s*)?(\d+(?:/\d+)?)', 'legal_framework'),
            (r'\b(?:Partido|Movimiento|Frente|Coalición)\s+([A-Z][a-záéíóúñü\s]+)', 'political_organization'),
            (r'\b(?:Provincia|Ciudad)\s+(?:de\s+)?([A-Z][a-záéíóúñü\s]+)', 'geographic_entity')
        ]
        
        for pattern, entity_type in title_patterns:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                entity = PoliticalEntity(
                    text=match.group(),
                    label=entity_type.upper(),
                    start=match.start(),
                    end=match.end(),
                    confidence=0.75,
                    entity_type=entity_type
                )
                entities.append(entity)
        
        return entities
    
    def _deduplicate_and_enhance(self, entities: List[PoliticalEntity], text: str, doc_year: int = None) -> List[PoliticalEntity]:
        """Remove duplicates and enhance entity information."""
        
        # Sort by start position and confidence
        entities.sort(key=lambda x: (x.start, -x.confidence))
        
        # Deduplicate overlapping entities
        final_entities = []
        for entity in entities:
            # Check for overlap with existing entities
            overlap = False
            for existing in final_entities:
                if (entity.start < existing.end and entity.end > existing.start):
                    # Keep entity with higher confidence
                    if entity.confidence <= existing.confidence:
                        overlap = True
                        break
                    else:
                        # Remove lower confidence entity
                        final_entities.remove(existing)
            
            if not overlap:
                # Enhance entity with additional info
                enhanced_entity = self._enhance_entity(entity, text, doc_year)
                final_entities.append(enhanced_entity)
        
        return final_entities
    
    def _enhance_entity(self, entity: PoliticalEntity, text: str, doc_year: int = None) -> PoliticalEntity:
        """Enhance entity with additional metadata."""
        
        # Add subtype classification
        entity.subtype = self._classify_subtype(entity)
        
        # Add temporal scope if not already present
        if entity.temporal_scope is None and doc_year:
            entity.temporal_scope = self._estimate_temporal_scope(entity, doc_year)
        
        # Add geographic scope
        entity.geographic_scope = self._identify_geographic_scope(entity, text)
        
        # Add political family
        if entity.political_family is None:
            entity.political_family = self._identify_political_family(entity)
        
        return entity
    
    def _classify_subtype(self, entity: PoliticalEntity) -> str:
        """Classify entity subtype based on text and context."""
        text_lower = entity.text.lower()
        
        for entity_type, subtypes in self.political_subtypes.items():
            if entity.entity_type == entity_type:
                for subtype in subtypes:
                    if subtype.replace('_', ' ') in text_lower:
                        return subtype
        
        return 'unclassified'
    
    def _estimate_temporal_scope(self, entity: PoliticalEntity, doc_year: int) -> Tuple[int, int]:
        """Estimate temporal scope for entity."""
        # Default to document year ± 10 years
        return (max(1810, doc_year - 10), min(2025, doc_year + 10))
    
    def _identify_geographic_scope(self, entity: PoliticalEntity, text: str) -> str:
        """Identify geographic scope from context."""
        provinces = [
            'Buenos Aires', 'Córdoba', 'Santa Fe', 'Mendoza', 'Tucumán',
            'Entre Ríos', 'Salta', 'Misiones', 'Chaco', 'Corrientes',
            'Santiago del Estero', 'San Juan', 'Jujuy', 'Río Negro',
            'Neuquén', 'Formosa', 'Chubut', 'San Luis', 'Catamarca',
            'La Rioja', 'La Pampa', 'Santa Cruz', 'Tierra del Fuego'
        ]
        
        for province in provinces:
            if province.lower() in text.lower():
                return province
        
        return 'Nacional'
    
    def _identify_political_family(self, entity: PoliticalEntity) -> str:
        """Identify political family/alignment."""
        text_lower = entity.text.lower()
        
        family_keywords = {
            'Peronista': ['perón', 'peronista', 'justicialista', 'pj'],
            'Radical': ['radical', 'ucr', 'yrigoyen', 'alfonsín'],
            'Kirchnerista': ['kirchner', 'cámpora', 'cristina', 'néstor'],
            'PRO': ['macri', 'pro', 'propuesta republicana'],
            'Libertario': ['milei', 'libertad avanza', 'libertario']
        }
        
        for family, keywords in family_keywords.items():
            if any(keyword in text_lower for keyword in keywords):
                return family
        
        return 'Independiente'

# Factory function for easy instantiation
def create_world_class_ner():
    """Create and return configured world-class NER system."""
    return WorldClassPoliticalNER()

__all__ = ['WorldClassPoliticalNER', 'PoliticalEntity', 'create_world_class_ner']