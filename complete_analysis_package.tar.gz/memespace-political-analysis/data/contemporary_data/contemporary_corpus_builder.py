"""
Contemporary Political Corpus Builder

Builds a comprehensive contemporary corpus (2003-2025) covering:
- Kirchnerismo period (2003-2015)
- Macrismo period (2015-2019)  
- Alberto Fernández period (2019-2023)
- Milei period (2023-present)
"""

import pandas as pd
from typing import Dict, List
from datetime import datetime

class ContemporaryCorpusBuilder:
    """
    Builds comprehensive contemporary political corpus for world-class analysis.
    """
    
    def __init__(self):
        self.corpus = []
        self.periods = {
            'kirchnerismo': (2003, 2015),
            'macrismo': (2015, 2019),
            'alberto_fernandez': (2019, 2023),
            'milei': (2023, 2025)
        }
    
    def build_complete_corpus(self) -> pd.DataFrame:
        """Build complete contemporary corpus."""
        
        # Kirchnerismo period (2003-2015)
        self._add_kirchnerismo_documents()
        
        # Macrismo period (2015-2019)
        self._add_macrismo_documents()
        
        # Alberto Fernández period (2019-2023)
        self._add_alberto_documents()
        
        # Milei period (2023-present)
        self._add_milei_documents()
        
        # Additional key events and speeches
        self._add_key_political_events()
        
        # Convert to DataFrame
        df = pd.DataFrame(self.corpus)
        
        print(f"Built contemporary corpus with {len(df)} documents")
        print(f"Period coverage: {df['year'].min()}-{df['year'].max()}")
        
        return df
    
    def _add_kirchnerismo_documents(self):
        """Add Kirchnerismo period documents (2003-2015)."""
        
        # Néstor Kirchner (2003-2007)
        self.corpus.extend([
            {
                'document_id': 'NK_Inaugural_2003',
                'author': 'Néstor Carlos Kirchner',
                'year': 2003,
                'title': 'Discurso Inaugural Presidencial',
                'text': """Vengo a proponerles un sueño: reconstruir nuestra propia identidad como Nación. 
                Vengo a proponerles un sueño: que Argentina vuelva a ser el país generoso que supimos conseguir.
                No vengo con rencores, vengo con memoria. La memoria de nuestro pueblo que nos permite 
                entender el presente y construir el futuro. Hemos llegado para quedarnos, para transformar 
                desde la política y para que la política transforme. La patria es el otro, dijo Evita.
                
                Queremos una Argentina normal, un país serio. Necesitamos un capitalismo nacional que genere 
                las alternativas que permitan reinstalar la movilidad social ascendente. Vamos por una 
                Argentina justa, libre y soberana. El desendeudamiento, el crecimiento con inclusión social 
                y el fortalecimiento institucional son nuestros objetivos centrales.""",
                'province': 'Nacional',
                'political_family': 'Kirchnerista',
                'outcome': 'transformative_presidency'
            },
            {
                'document_id': 'NK_Deuda_2005',
                'author': 'Néstor Carlos Kirchner',
                'year': 2005,
                'title': 'Anuncio Cancelación Deuda FMI',
                'text': """Hoy la Argentina le dice definitivamente adiós al Fondo Monetario Internacional.
                Salimos del default más grande de la historia mundial. Cancelo la deuda con el FMI
                anticipadamente porque no quiero que vuelvan a condicionar a los argentinos.
                
                El FMI no solo prestó dinero, sino que condicionó las políticas económicas y sociales.
                Hoy recuperamos nuestra soberanía económica. Los argentinos decidiremos nuestro destino.
                Esta decisión marca un antes y un después en la historia argentina. Nunca más el ajuste,
                nunca más las recetas que empobrece a nuestro pueblo.
                
                Defendemos el superávit fiscal twin, pero no a costa del hambre de nuestro pueblo.
                El Estado vuelve a cumplir su rol de garante de la justicia social.""",
                'province': 'Nacional', 
                'political_family': 'Kirchnerista',
                'outcome': 'sovereignty_recovery'
            },
            
            # Cristina Fernández de Kirchner (2007-2015)
            {
                'document_id': 'CFK_Inaugural_2007',
                'author': 'Cristina Fernández de Kirchner',
                'year': 2007,
                'title': 'Primer Discurso Inaugural',
                'text': """Asumo la primera magistratura de la Nación con la responsabilidad y el honor que 
                significa ser la primera mujer elegida Presidenta por el voto popular en doscientos años 
                de historia. Represento a las mujeres que lucharon por la igualdad y por sus derechos.
                
                Profundizaremos el modelo de crecimiento con inclusión social que iniciamos en 2003.
                Vamos a seguir desendeudando el país y redistribuyendo la riqueza. La patria es el otro,
                pero también la patria somos nosotros cuando defendemos nuestros derechos.
                
                Convocaremos a todos los argentinos sin exclusiones. Necesitamos una Argentina 
                que vuelva a creer en sí misma, en sus instituciones y en su futuro.""",
                'province': 'Nacional',
                'political_family': 'Kirchnerista', 
                'outcome': 'first_female_president'
            },
            {
                'document_id': 'CFK_125_2008',
                'author': 'Cristina Fernández de Kirchner',
                'year': 2008,
                'title': 'Conflicto con el Campo - Resolución 125',
                'text': """Las retenciones móviles son un instrumento de redistribución de la renta extraordinaria
                que genera el sector agropecuario en momentos de precios internacionales excepcionales.
                No es un impuesto al campo, es una participación del Estado en la renta diferencial.
                
                El campo no puede pretender llevarse toda la renta sin compartir nada con el conjunto
                de la sociedad argentina. Los recursos naturales son de todos los argentinos.
                Estas medidas permitirán financiar obras de infraestructura, escuelas y hospitales.
                
                No vamos a ceder ante las presiones corporativas. El gobierno nacional representa
                los intereses de todos los argentinos, no de un sector particular. La democracia
                no se resuelve en las rutas sino en las urnas.""",
                'province': 'Nacional',
                'political_family': 'Kirchnerista',
                'outcome': 'major_conflict_polarization'
            },
            {
                'document_id': 'CFK_Medios_2009',
                'author': 'Cristina Fernández de Kirchner',
                'year': 2009,
                'title': 'Ley de Servicios de Comunicación Audiovisual',
                'text': """Sancionamos una ley democrática que desmonopoliza los medios de comunicación.
                Durante décadas el monopolio mediático construyó un sentido común conservador que
                defendía los intereses de pocos contra los derechos de las mayorías.
                
                Esta ley garantiza el pluralismo, la diversidad cultural y la democratización de la palabra.
                Los medios públicos recuperan su función pedagógica y cultural. Terminamos con la
                concentración mediática que asfixiaba las voces populares.
                
                La comunicación es un derecho humano. No puede estar en manos de grupos económicos
                que subordinan la información a sus intereses comerciales y políticos. Democratizamos
                para que todos los sectores tengan voz en el espacio público.""",
                'province': 'Nacional',
                'political_family': 'Kirchnerista',
                'outcome': 'media_democratization'
            },
            {
                'document_id': 'CFK_YPF_2012',
                'author': 'Cristina Fernández de Kirchner',
                'year': 2012,
                'title': 'Expropiación de YPF',
                'text': """Recuperamos YPF para los argentinos. Durante años Repsol saqueó nuestros recursos
                naturales sin invertir lo necesario para mantener el autoabastecimiento energético.
                La soberanía energética es condición indispensable para el desarrollo nacional.
                
                YPF vuelve a manos argentinas para garantizar la matriz energética que necesita nuestro
                país. No podemos depender de decisiones empresarias que priorizan la rentabilidad
                por sobre las necesidades nacionales. El petróleo y el gas son nuestros.
                
                Esta decisión ratifica nuestra independencia económica y fortalece la capacidad del
                Estado para planificar el desarrollo estratégico. Vamos por la soberanía energética.""",
                'province': 'Nacional',
                'political_family': 'Kirchnerista', 
                'outcome': 'energy_sovereignty'
            },
            {
                'document_id': 'CFK_Fondos_Buitre_2014',
                'author': 'Cristina Fernández de Kirchner',
                'year': 2014,
                'title': 'Denuncia contra Fondos Buitre',
                'text': """Los fondos buitre representan la especulación financiera internacional más salvaje.
                Compraron deuda argentina en default por centavos y ahora pretenden cobrar el 1600%
                de lo que pagaron. Es extorsión financiera contra la República Argentina.
                
                No vamos a pagar porque sería un precedente peligroso para todos los países emergentes.
                Estos fondos especulativos amenazan la estabilidad del sistema financiero internacional.
                Argentina no se va a arrodillar ante los especuladores.
                
                Defendemos la reestructuración de deuda que hicimos y que aceptó el 93% de los bonistas.
                Los holdouts no pueden chantajear a un país entero. Vamos a luchar en todos los tribunales
                internacionales para defender nuestra soberanía financiera.""",
                'province': 'Nacional',
                'political_family': 'Kirchnerista',
                'outcome': 'financial_sovereignty_defense'
            }
        ])
    
    def _add_macrismo_documents(self):
        """Add Macrismo period documents (2015-2019)."""
        
        self.corpus.extend([
            {
                'document_id': 'MM_Inaugural_2015',
                'author': 'Mauricio Macri',
                'year': 2015,
                'title': 'Discurso Inaugural Presidencial',
                'text': """Llego a la Presidencia para unir a los argentinos. Terminamos con la grieta que
                dividió al país durante años. Vamos a construir un país normal, predecible, donde se
                respeten las instituciones y la división de poderes.
                
                Argentina tiene que insertarse inteligentemente en el mundo. Necesitamos inversión,
                tecnología y crear empleos de calidad. Vamos a combatir la inflación, reducir la pobreza
                y generar las condiciones para el crecimiento sostenible.
                
                Convoco a todos los sectores políticos y sociales a trabajar juntos por el país que
                merecemos. Dejamos atrás los enfrentamientos estériles. Es tiempo de diálogo, acuerdo
                y responsabilidad. Juntos vamos a cambiar la historia.""",
                'province': 'Nacional',
                'political_family': 'PRO',
                'outcome': 'change_government'
            },
            {
                'document_id': 'MM_Reformas_2017',
                'author': 'Mauricio Macri', 
                'year': 2017,
                'title': 'Reforma Previsional y Laboral',
                'text': """Las reformas que enviamos al Congreso son indispensables para modernizar el país.
                El sistema previsional necesita sustentabilidad para garantizar las jubilaciones futuras.
                La reforma laboral genera empleo formal y protege a los trabajadores.
                
                No podemos seguir sosteniendo un sistema que no cierra y que compromete el futuro
                de nuestros hijos y nietos. Estas reformas nos equiparan con países desarrollados
                que tienen marcos normativos modernos y eficientes.
                
                Entendemos que generen resistencias, pero son necesarias para el desarrollo del país.
                El gradualismo nos permite hacer los cambios sin traumas ni sobresaltos.""",
                'province': 'Nacional',
                'political_family': 'PRO',
                'outcome': 'structural_reforms'
            },
            {
                'document_id': 'MM_FMI_2018', 
                'author': 'Mauricio Macri',
                'year': 2018,
                'title': 'Acuerdo con el Fondo Monetario Internacional',
                'text': """Hemos decidido solicitar asistencia financiera al Fondo Monetario Internacional
                para acelerar nuestro programa económico y mitigar el impacto de la turbulencia global.
                Este acuerdo nos da previsibilidad y respaldo internacional.
                
                No es un programa de ajuste tradicional. Mantenemos nuestras prioridades: proteger
                a los más vulnerables, sostener la obra pública y defender el empleo. El FMI acompaña
                nuestro plan de estabilización macroeconómica.
                
                Esta decisión evita una crisis mayor y nos permite ordenar la economía de manera gradual.
                Vamos a cumplir con las metas acordadas porque son las que el país necesita.""",
                'province': 'Nacional', 
                'political_family': 'PRO',
                'outcome': 'return_to_imf'
            },
            {
                'document_id': 'MM_Derrota_2019',
                'author': 'Mauricio Macri',
                'year': 2019,
                'title': 'Reconocimiento de Derrota Electoral',
                'text': """Los argentinos han decidido en las urnas y respetamos profundamente esa decisión.
                Felicito a Alberto Fernández y a Cristina Kirchner por el triunfo obtenido.
                Vamos a garantizar una transición ordenada y republicana.
                
                Hicimos todo lo que pudimos con las herramientas que teníamos. Cometimos errores
                pero actuamos siempre con honestidad y transparencia. Dejamos un país con instituciones
                más sólidas y una democracia más madura.
                
                Seguiremos participando de la vida política del país desde nuestro lugar de oposición
                responsable. La alternancia democrática es un valor que debemos consolidar.""",
                'province': 'Nacional',
                'political_family': 'PRO', 
                'outcome': 'electoral_defeat'
            }
        ])
    
    def _add_alberto_documents(self):
        """Add Alberto Fernández period documents (2019-2023)."""
        
        self.corpus.extend([
            {
                'document_id': 'AF_Inaugural_2019',
                'author': 'Alberto Fernández',
                'year': 2019,
                'title': 'Discurso Inaugural Presidencial', 
                'text': """Vengo a convocar a la unidad nacional. Argentina necesita sanar las heridas que
                la grieta abrió en nuestra sociedad. Vamos a gobernar para todos los argentinos,
                sin distinciones partidarias ni ideológicas.
                
                La prioridad es atender la emergencia social y económica. Millones de argentinos
                la están pasando mal y el Estado debe estar presente. Volvemos a poner a la política
                al servicio de la gente, especialmente de los que menos tienen.
                
                Reconstruiremos las instituciones dañadas y restauraremos los vínculos con el mundo
                desde una perspectiva federal y popular. Cristina Kirchner me honra con su confianza
                y juntos vamos a sacar a Argentina adelante.""",
                'province': 'Nacional',
                'political_family': 'Peronista',
                'outcome': 'peronist_return'
            },
            {
                'document_id': 'AF_Pandemia_2020',
                'author': 'Alberto Fernández',
                'year': 2020,
                'title': 'Gestión de la Pandemia COVID-19',
                'text': """Ante la pandemia mundial priorizamos la vida y la salud de los argentinos.
                Las medidas sanitarias que adoptamos salvaron miles de vidas. Preferimos tener
                10% más de pobreza que 100.000 muertos como pasó en otros países.
                
                El Estado nacional asumió la responsabilidad de cuidar a su pueblo. Fortalecimos
                el sistema sanitario, garantizamos el acceso universal a las vacunas y sostuvimos
                los ingresos de los trabajadores durante la cuarentena.
                
                La pandemia demostró que el mercado solo no alcanza. Necesitamos un Estado presente
                que garantice derechos básicos y proteja a los más vulnerables en momentos de crisis.""",
                'province': 'Nacional',
                'political_family': 'Peronista',
                'outcome': 'pandemic_management'
            },
            {
                'document_id': 'AF_Deuda_2020',
                'author': 'Alberto Fernández', 
                'year': 2020,
                'title': 'Reestructuración de la Deuda Externa',
                'text': """Logramos reestructurar la deuda externa en términos favorables para Argentina.
                Evitamos el default y conseguimos quitas y plazos que hacen sustentable el pago.
                La deuda que heredamos era impagable y condicionaba cualquier política de desarrollo.
                
                Esta reestructuración nos permite recuperar márgenes de maniobra fiscal para invertir
                en educación, salud y obra pública. No vamos a ajustar sobre las espaldas de los
                que menos tienen para pagar una deuda que no generamos.
                
                Priorizamos el crecimiento económico y la creación de empleo. Una Argentina que crece
                puede pagar sus deudas. Una Argentina en recesión no puede pagar ni desarrollarse.""",
                'province': 'Nacional',
                'political_family': 'Peronista', 
                'outcome': 'debt_restructuring'
            }
        ])
    
    def _add_milei_documents(self):
        """Add Milei period documents (2023-present)."""
        
        self.corpus.extend([
            {
                'document_id': 'JM_Campaña_2023',
                'author': 'Javier Gerardo Milei',
                'year': 2023,
                'title': 'Propuesta Económica de Campaña',
                'text': """Vamos a terminar con 100 años de decadencia argentina. El modelo estatista fracasó
                y empobreció a nuestro país. Necesitamos un cambio radical hacia la libertad económica.
                La receta es simple: motosierra al Estado y dolarización de la economía.
                
                Vamos a cerrar el Banco Central porque es una estafa piramidal que genera inflación.
                Eliminaremos ministerios innecesarios y reduciremos drásticamente el gasto público.
                El Estado no genera riqueza, la destruye. Los empresarios y trabajadores generan riqueza.
                
                Argentina tiene que volver a ser el país que era antes del peronismo. Libertad o esclavitud,
                no hay punto medio. Los políticos son una casta que vive del pueblo trabajador.""",
                'province': 'Nacional',
                'political_family': 'Libertario',
                'outcome': 'disruptive_campaign'
            },
            {
                'document_id': 'JM_Inaugural_2023',
                'author': 'Javier Gerardo Milei',
                'year': 2023,
                'title': 'Discurso Inaugural Presidencial',
                'text': """Hoy comienza la reconstrucción de Argentina. No hay plata y la herencia que recibimos
                es catastrófica. Vamos a hacer el ajuste fiscal más grande de la historia argentina
                porque no se puede gastar más de lo que se tiene.
                
                Terminamos con el modelo degenerado que nos sumió en la decadencia. Vamos hacia una
                economía de libre mercado donde los recursos se asignen eficientemente. El Estado
                se retira de donde no debe estar y se concentra en sus funciones básicas.
                
                Este es el comienzo de una nueva Argentina próspera y libre. No será fácil pero es
                el único camino para salir de la pobreza y la inflación. Viva la libertad, carajo.""",
                'province': 'Nacional', 
                'political_family': 'Libertario',
                'outcome': 'libertarian_government'
            },
            {
                'document_id': 'JM_DNU_2024',
                'author': 'Javier Gerardo Milei',
                'year': 2024,
                'title': 'Decreto de Necesidad y Urgencia - Desregulación',
                'text': """Mediante este DNU desregulamos sectores clave de la economía que estaban
                intervenidos por el Estado. Eliminamos controles de precios, liberamos el mercado
                de alquileres y facilitamos el despido de empleados estatales.
                
                Estas medidas van a generar más competencia, mejores precios y mayor eficiencia.
                El Estado no puede seguir asfixiando la iniciativa privada con regulaciones obsoletas.
                Confiamos en el mercado y en la capacidad de los argentinos para generar riqueza.
                
                Los que se oponen defienden privilegios corporativos. Nosotros defendemos la libertad
                de todos los argentinos para producir, comerciar y progresar sin trabas burocráticas.""",
                'province': 'Nacional',
                'political_family': 'Libertario',
                'outcome': 'radical_deregulation'
            }
        ])
    
    def _add_key_political_events(self):
        """Add key political events and crises."""
        
        self.corpus.extend([
            {
                'document_id': 'Crisis_2001',
                'author': 'Múltiples actores',
                'year': 2001,
                'title': 'Crisis del 2001 - Que se vayan todos',
                'text': """La crisis del 2001 marcó el colapso del modelo de convertibilidad y la deslegitimación
                masiva de la clase política. "Que se vayan todos" expresó el hartazgo popular con
                dirigentes que llevaron al país a la peor crisis de su historia.
                
                El default de la deuda externa, el corralito bancario y la represión del 19 y 20 de
                diciembre generaron una crisis de representación sin precedentes. La pueblada derrocó
                al gobierno de De la Rúa y llevó a una crisis institucional profunda.
                
                Esta crisis abrió el espacio para el surgimiento del kirchnerismo y reconfiguró
                completamente el sistema político argentino. Fue el fin del consenso de Washington.""",
                'province': 'Nacional',
                'political_family': 'Transversal',
                'outcome': 'systemic_crisis'
            },
            {
                'document_id': 'Elecciones_2015',
                'author': 'Análisis Electoral',
                'year': 2015,
                'title': 'Alternancia Democrática - Fin del Kirchnerismo',
                'text': """Las elecciones de 2015 marcaron la primera alternancia partidaria desde la
                restauración democrática sin crisis económica de por medio. Mauricio Macri logró
                quebrar la hegemonía kirchnerista en las urnas.
                
                La campaña se definió entre el continuismo de Daniel Scioli y el cambio de Macri.
                La polarización fue menor que en elecciones anteriores. Ganó el discurso del gradualismo
                y la normalización institucional.
                
                Esta elección demostró la madurez del sistema democrático argentino y la capacidad
                de los ciudadanos para cambiar gobiernos por la vía electoral.""",
                'province': 'Nacional',
                'political_family': 'Transversal',
                'outcome': 'democratic_alternation'
            },
            {
                'document_id': 'PASO_2019',
                'author': 'Análisis Electoral',
                'year': 2019, 
                'title': 'PASO 2019 - Crisis del Macrismo',
                'text': """Los resultados de las PASO del 11 de agosto generaron una crisis cambiaria
                y financiera que selló la suerte del gobierno de Macri. La diferencia de 15 puntos
                a favor del Frente de Todos sorprendió a mercados y analistas.
                
                La reacción de los mercados demostró la fragilidad del modelo macrista dependiente
                del financiamiento externo. El riesgo país se disparó y el peso se devaluó brutalmente.
                
                Estos resultados anticiparon el retorno del peronismo al poder y el fin del
                experimento neoliberal de Cambiemos.""",
                'province': 'Nacional',
                'political_family': 'Transversal', 
                'outcome': 'electoral_anticipation'
            }
        ])

def create_contemporary_corpus() -> pd.DataFrame:
    """Create and return complete contemporary political corpus."""
    builder = ContemporaryCorpusBuilder()
    return builder.build_complete_corpus()

if __name__ == "__main__":
    # Build corpus
    corpus = create_contemporary_corpus()
    
    # Save to file
    corpus.to_json('contemporary_political_corpus.json', orient='records', force_ascii=False, indent=2)
    corpus.to_csv('contemporary_political_corpus.csv', index=False)
    
    print(f"Contemporary corpus built with {len(corpus)} documents")
    print(f"Coverage: {corpus['year'].min()} - {corpus['year'].max()}")
    print(f"Political families: {corpus['political_family'].unique()}")